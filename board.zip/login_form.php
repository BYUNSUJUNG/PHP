<?php //1701140_변수정 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>로그인 페이지</title>
		<!--Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	</head>
	<body> 
		<div class="container">
			<form action="login.php" method="post"> <!--post방식으로 값 전달-->
			<div class="form-group"> <!-- id -->
			  <label for="id">Id:</label>
			  <input type="text" class="form-control" id="id" name="id">
			</div>
			<div class="form-group"> <!-- password -->
			  <label for="pw">Password:</label>
			  <input type="password" class="form-control" id="pw" name="pw">
			</div>
			<button type="submit" class="btn btn-success">로그인</button> <!-- submit, 로그인 -->
		</div>	
	</body>
</html>
