<?php //1701140_변수정 ?>
<?php
	class boardDao {
		
		private $db;  // PDO 객체를 저장하기 위한 프로퍼티
		
		// DB에 접속하고 PDO 객체를 $db에 저장
		public function __construct() {
			try {
				$this->db = new PDO("mysql:host=localhost;dbname=php", "root", "8498"); 
				// PDO객체 생성 
				// "URL"를 입력하면 연결되는거임
				$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			} catch(PDOException $e) {
				exit($e->getMessage());
			}
		}

		// view.php에서 사용됨
		function getMsg($num){ 
            try{
                $pstmt = $this->db->prepare("select * from board where num=:num");
                $pstmt->bindValue(":num", $num, PDO::PARAM_STR);
                $pstmt->execute();
                $result=$pstmt->fetch(PDO::FETCH_ASSOC);
            }catch(PDOException $e){
                exit($e->getMessage());
            }
			return $result;
		}
		
		// write.php에서 사용됨
		function insertBoard($writer, $title, $content) { 
			try {
				$sql = "insert into board(writer,title,content) values(:writer,:title,:content)";
				$pstmt = $this->db->prepare($sql);
				$pstmt->bindValue(":writer",$writer,PDO::PARAM_STR);
				$pstmt->bindValue(":title",$title,PDO::PARAM_STR);
				$pstmt->bindValue(":content",$content,PDO::PARAM_STR);
				$pstmt->execute(); // 실행
			} catch(PDOException $e) {
				exit($e->getMessage());
			}
		}

		// view.php에서 사용됨
		function increaseHits($num) { 
			try {
				$sql = "update board set hits=hits+1 where num=:num";
				$pstmt = $this->db->prepare($sql);
				$pstmt->bindValue(":num",$num,PDO::PARAM_STR);
				$pstmt->execute(); // 실행
			} catch(PDOException $e) {
				exit($e->getMessage());
			}
		}

		// 모든 업로드된 파일 정보 반환(2차원 배열)
		// board.php에서 사용됨
		function getManyMsgs() { 
			//sql: "select * from board"
			$sql="select * from board";
			try {
				$pstmt=$this->db->prepare($sql);
				// bindValue 필요 없음
				$pstmt->execute();
				// 하나씩 가져올때는 fetch을 사용함
				// 일차원배열로 만들어서 가져와주세요. FETCH_ASSOC을 사용함
				// $pstmt->fetch(PDO::FETCH_ASSOC);
				// 하지만 한꺼번에 할 것이기 때문에 fetchAll을 사용한다.
				$msg=$pstmt->fetchAll(PDO::FETCH_ASSOC);
			} catch(PDOException $e){
				exit($e->getMessage());
			}
			return $msg;
		
		}

		// modify.php에서 사용됨
		function updateBoard($num, $writer, $title, $content) { 
			try {
				$sql = "update board set writer=:writer, title=:title, content=:content where num=:num";
				$pstmt = $this->db->prepare($sql);
				$pstmt->bindValue(":num",$num,PDO::PARAM_STR);
				$pstmt->bindValue(":writer",$writer,PDO::PARAM_STR);
				$pstmt->bindValue(":title",$title,PDO::PARAM_STR);
				$pstmt->bindValue(":content",$content,PDO::PARAM_STR);
				$pstmt->execute(); // 실행
			} catch(PDOException $e) {
				exit($e->getMessage());
			}
		}

		// delete.php에서 사용됨
		function deleteBoard($num) { 
			try { 
				$sql = "delete from board where num=:num";
				$pstmt = $this->db->prepare($sql);
				$pstmt->bindValue(":num",$num,PDO::PARAM_STR);
				$pstmt->execute(); // 실행
			} catch(PDOException $e) {
				exit($e->getMessage());
			}
		}
	}
?>