<?php //1701140_변수정 ?>
<?php
	define ("BOARD_PAGE", "board.php"); // board.php를 BOARD_PAGE로 재정의
	function requestValues($name) {
		return isset($_REQUEST[$name])?$_REQUEST[$name]:""; // 받은 값을 다시 돌려주는 역할
	}
	function errorBack($msg) { // error 상황에 전 페이지로 돌아가는 역할
?>
		<!doctype html>
		<html>
		<head>
			<meta charset="utf-8">
		</head>
		<body>
			<script>
				alert('<?= $msg ?>'); // 창 띄움
				history.back(); // 전 페이지로 돌아감
			</script>
		</body>
		</html>
<?php
		exit(); // 끝내기
	} // end of errorBack() 
	function okGo($msg, $url) {
?>
		<!doctype html>
		<html>
		<head>
			<meta charset="utf-8">
		</head>
		<body>
			<script>
				alert('<?= $msg ?>'); // 창 띄움
				location.href = '<?= $url ?>'; // 받은 url 주소로 이동함
			</script>
		</body>
		</html>
<?php
	} // end of okGo($msg, $url)
?>