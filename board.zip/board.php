<?php //1701140_변수정 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>게시판</title>
		<!--Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
		<script>
			function go(page) {
				if(page=='login') location.href="login_form.php";
				else if(page=='register') location.href="register_form.php";	
				else location.href='write_form.php';
			}
		</script>
		<style>
			.user_box {
				margin-top: 10px;
				margin-left: 800px;
			}
		</style>
	</head>
	<body>
		<?php 
			session_start(); 	// session 사용을 하기 전 start
		?>
		<div class="container">
			<?php
				$id = isset($_SESSION["id"])?$_SESSION["id"]:""; // session에 저장된 id가 존재하면 그것을 넣고 아니면 ""
				if(!$id) { // start of if
					// if(!로그인 사용자) {  //로그인을 하지 않은 사용자는 로그인 버튼과 회원가입 버튼이 보임
			?>
					<div class="user_box">
						<button class="btn btn-success" onclick="go('login')">로그인</button>
						<button class="btn btn-info" onclick="go('register')">회원가입</button>
					</div>
			<?php
				} // end of if
				 else { // start of else // //로그인을 한 사용자는 로그아웃 버튼과 정보수정 버튼이 보임
			?>
					<div class="user_box">
						<h3> <?php echo $_SESSION["name"] ?>님 환영합니다. </h3>
						<button class="btn btn-success" onclick="location.href='logout.php'">로그아웃</button>
						<button class="btn btn-info" onclick="location.href='update_form.php'">정보수정</button>
				 	</div>
			<?php
				} // end of else
			?>			
			<h2>게시물 목록</h2>
			<?php 
				require_once("boardDao.php"); // java inport와 유사함, once를 하면 한번만 읽어옴
				$dao = new boardDao(); 
				$msgs=$dao->getManyMsgs(); //boardDao의 getManyMsgs()를 $msgs에 담음
			?>
			<table class="table table-hover">
				<tr>
					<th>번호</th>
					<th>제목</th>
					<th>작성자</th>
					<th>작성일지</th>
					<th>조회수</th>
				</tr>
				<?php foreach($msgs as $row) :  // $record 와 $row 는 같은 의미로 사용된다. ?>   
					<tr>
						<td> <?= $row["Num"] ?></td>
						<td> 
							<a href="view.php?num=<?= $row["Num"] ?>&writer=<?= $row["Writer"]?>">
								<? 
									/* row는 서버에서 실행되어 값만 가져오는 것이기에 ""안에 ""가 가능한 것이다.
										하이퍼링크를 클릭할 때 view.php로 $row["Num"] 값과 $row["Writer"] 값을 넘겨준다. */
								?> 
								<?= $row["Title"] ?>
							</a>
						</td>
						<td> <?= $row["Writer"] ?></td>
						<td> <?= $row["Regtime"] ?></td>
						<td> <?= $row["Hits"] ?></td>
					</tr>
				<?php endforeach ?>	
			</table>
			<input class="btn btn-primary" type="button" value="글쓰기" onclick="go('writer')">
		</div>
	</body>
</html>
