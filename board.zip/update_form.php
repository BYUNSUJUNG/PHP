<?php //1701140_변수정 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>정보 수정 페이지</title>
		<!--Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	</head>
	<body> 
		<?php
			require_once("MemberDao.php"); // java inport와 유사함, require_once를 하면 한번만 읽어옴
			require_once("tools.php");
			
			session_start(); // 세션 시작
			
			$sid = isset($_SESSION["id"])?$_SESSION["id"]:"";
			
			if(!$sid) { // id가 없을 때
				errorBack("로그인부터 하시오");
				/* 
					tools.php의 함수, 메세지 창을 띄우고 전 페이지로 이동함
					alert('<?= $msg ?>'); // 창 띄움
					history.back(); 
				*/
			} 
			$mdao = new MemberDao(); // 생성자 실행 -> db연결됨
			$member = $mdao->getMember($sid); // 아이디가 프라이머리키라서 레코드가 하나뿐
		?>
		<div class="container">
		<h2>회원 정보 수정</h2>
			<form action="update.php" method="post">
			<div class="form-group">
			  <label for="name">Name:</label> <!-- name -->
			  <input type="text" class="form-control" id="name" name="name" 
			  value="<?= $member["name"]?>">
			</div>
			<div class="form-group">
			  <label for="id">Id:</label> <!-- id --> 
			  <input type="text" class="form-control" id="id" name="id" 
			  value="<?= $member["id"]?>" readonly> 
			</div>
			<div class="form-group">
			  <label for="pw">Password:</label> <!-- password -->
			  <input type="password" class="form-control" id="pw" name="pw"
			  value="<?= $member["pw"]?>">
			</div>
			<button type="submit" class="btn btn-default">정보 수정</button> <!-- submit, 정보 수정 -->
		</div>	
	</body>
</html>
