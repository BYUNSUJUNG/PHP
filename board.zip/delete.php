<?php //1701140_변수정 ?>
<?php
	require_once("boardDao.php"); // java inport와 유사함, require_once를 하면 한번만 읽어옴
	require_once("tools.php");

    //  클라이언트가 송신한 num값을 읽는다.
    $num = requestValues("num");

    if($num) { // $num 값이 있을 때
        $dao = new boardDao();  // 생성자 실행 -> db연결됨
        $dao->deleteBoard($num); // 삭제할 값을 넘겨줌
        okGo("글 삭제 완료", BOARD_PAGE);
        /*
			tools.php의 함수, 메세지 창을 띄우고 BOARD_PAGE로 이동함
			alert('<?= $msg ?>')
			location.href='<?= $url ?>' 
		*/
    } else { // $num 값이 있을 때
        errorBack("글이 존재하지 않습니다");
    }
    /* 
        tools.php의 함수, 메세지 창을 띄우고 전 페이지로 이동함
        alert('<?= $msg ?>'); // 창 띄움
        history.back(); 
    */
?>
 