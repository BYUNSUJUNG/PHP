<?php //1701140_변수정 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>회원가입 페이지</title>
		<!--Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	</head>
	<body> 
		<div class="container">
		<h2>회원 가입</h2>
			<form action="register.php" method="post">
			<div class="form-group">
			  <label for="name">Name:</label> <!-- name -->
			  <input type="text" class="form-control" id="name" name="name">
			</div>
			<div class="form-group">
			  <label for="id">Id:</label> <!-- id -->
			  <input type="text" class="form-control" id="id" name="id">
			</div>
			<div class="form-group">
			  <label for="pw">Password:</label> <!-- pw -->
			  <input type="password" class="form-control" id="pw" name="pw">
			</div>
			<button type="submit" class="btn btn-default">회원가입</button> <!-- submit, 회원가입 -->
		</div>	
	</body>
</html>
